

import './App.scss';
import Home from './Pages/Home';
import About from './Pages/About';

import {BrowserRouter, Routes, Route } from "react-router-dom";

import TopNavBar from './Components/TopNavBar';
import Dashboard from './Pages/Dashboard';

import Login from './Pages/Login';
import CreateUser from './Pages/CreateUser';
import ViewUser from './Pages/ViewUser';
import AboutUser from './Pages/AboutUser';

import LoginForm from './Pages/LoginForm/LoginForm';
import Registration from './Pages/Registration/Registration';
import Signup from './Pages/Signup/Signup';
import Calc from './Pages/Calculator/calc';
import CustomerData from './Pages/Customers/CustomerData';




function App() {
  return (
    <div className="App">
        <BrowserRouter>
          <TopNavBar />
        
        <Routes>
          <Route path='/' element={ <Home /> } />
          <Route path='/home' element={ <Home /> } />
          <Route path='/about' element={ <About /> } >
               <Route path='aboutuser' element={ <AboutUser /> } />
          </Route>
          {/* <Route path='/customer' element={ <CustomerData /> } /> */}
          <Route path='/dashboard' element={ <Dashboard /> }>
               <Route path='login' element={ <Login /> } />
               <Route path='viewuser' element={ <ViewUser /> } />
               <Route path='createuser' element={ <CreateUser /> } />
          </Route>
          <Route path='/login' element={  <LoginForm /> } />
          <Route path='/register' element={ <Registration /> } />
          <Route path='/signup' element={ <Signup /> } />
          <Route path='/calculator' element={ <Calc /> } />
          <Route path='/customer' element={ <CustomerData /> } />
         
        </Routes>
        </BrowserRouter>
     
      
    </div>
  );
}

export default App;
