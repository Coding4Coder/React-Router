
import { useState } from "react";
import MainHeading from "../../Components/MainHeading";
import "./Calc.scss";


const Calc = () => {
        const[result, setResult] = useState("");


        const inputChange = (e) => {
            setResult(e.target.value)
        }
         const clear = () => {
            setResult("");
         }
    const del = () => {
        setResult (result.slice(0, -1));
    }

    const btnClick = (e) => {
        const btnValue = e.target.name;
        setResult(result.concat(btnValue));

    }

    const btnCalculate = () => {
        try {
            setResult(eval(result).toString());
        }
        catch (err)
        {
            setResult("Error !!!")
        }
       
    }


    return (
        <div className="main-container">
              <MainHeading pageTitle="Calculator" />

            <div className="calculator"> 
                <div className="calcInput">
                     <input type="text" value={result} onChange={inputChange} />
                </div>
                <div className="keypad">
                    <button className="clear" onClick={clear}>Clear</button>
                    <button className="del" onClick={del}>Del</button> <br />
                    <button name="7" onClick={btnClick}>7</button>
                    <button name="8" onClick={btnClick}>8</button>
                    <button name="9" onClick={btnClick}>9</button>
                    <button name="+" onClick={btnClick}>+</button><br />
                    <button name="4" onClick={btnClick}>4</button>
                    <button name="5" onClick={btnClick}>5</button>
                    <button name="6" onClick={btnClick}>6</button>
                    <button name="-" onClick={btnClick}>-</button><br />
                    <button name="1" onClick={btnClick}>1</button>
                    <button name="2" onClick={btnClick}>2</button>
                    <button name="3" onClick={btnClick}>3</button>
                    <button name="*" onClick={btnClick}>&times;</button><br />
                    <button name="." onClick={btnClick}>.</button>
                    <button name="0" onClick={btnClick}>0</button>
                    <button name="/" onClick={btnClick}>/</button>

                    <button name="=" onClick={btnCalculate}>=</button>

                </div>

         </div>

    </div>
    );
}

export default Calc;