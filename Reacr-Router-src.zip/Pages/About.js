
import "../scss/Main.scss";
import { Link, Outlet } from "react-router-dom";
import React from "react";
const About = () =>{
    return(
        <>
                <div className="main-container">
                    <h1 className="heading">
                        <Link className="link-title" to="/about/aboutuser">About page</Link>
                    </h1>
                    <Outlet />
                </div>
               
                  
               

        </>
    );
}

export default About;
