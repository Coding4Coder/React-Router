
import "../scss/Dashboard.scss";

const Login = () =>{
    return(
        <div className="card-box">
            <h1 className="heading">User - Login</h1>
            <div className="row g-0 bdr-top">
                <div className="col-sm-12">
                    <div className="login-box">
                        <h2 className="title">Please login here.. </h2>
                        </div>
                </div>
            </div>
            </div>
    );
}
export default Login;
