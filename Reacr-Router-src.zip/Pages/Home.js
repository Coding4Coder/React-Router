

import React from "react";
import MainHeading from "../Components/MainHeading";
import HomeUserData from "./HomeUserData";


const Home = () =>{
    return(
        <div className="main-container">
           <MainHeading pageTitle={"You're most welcome.."} />
            <HomeUserData />
            </div>
    );
}

export default Home;
