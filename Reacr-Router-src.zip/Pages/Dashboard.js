
import { Link, Outlet } from "react-router-dom";
import "../scss/Dashboard.scss";

const Dashboard = () =>{
    return(
        <div className="main-container">
             <h1 className="heading">
                <Link className="link-title" to="">Dashboard</Link>
             </h1>
            <div className="row g-0 bdr-top dashboard">
                <div className="col-sm-4">
                    <div className="login-box">
                        <Link to="/dashboard/login">Login </Link>
                   </div>
                </div>
                <div className="col-sm-4">
                    <div className="login-box">
                        <Link to="/dashboard/createuser">Create User </Link>
                    </div>
                </div>
                <div className="col-sm-4">
                    <div className="login-box">
                        <Link to="/dashboard/viewuser">View User </Link>
                     </div>
                </div>
            </div>

         <Outlet />

        </div>
    );
}
export default Dashboard;
