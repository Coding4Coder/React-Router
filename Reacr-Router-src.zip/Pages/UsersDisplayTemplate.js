

import classes from "../scss/Home.module.scss";

const UsersDisplayTemplate = (props) => {
    return (
        <div className={classes.card}>
             <div className={classes.cardBody}>
                {<img src={props.usersPhoto} alt="" /> }<br />
                {props.userName}<br />
                {props.userPhone}<br />
                {props.userGender}
             </div>
         </div>

    );
}

export default UsersDisplayTemplate;