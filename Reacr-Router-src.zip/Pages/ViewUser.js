
import "../scss/Dashboard.scss";

const ViewUser = () =>{
    return(
        <div className="card-box">
            <h1 className="heading">View User</h1>
            <div className="row g-0 bdr-top">
                <div className="col-sm-12">
                    <div className="login-box">
                        <h2 className="title">View User here.. </h2></div>
                </div>
            </div>
            </div>
    );
}
export default ViewUser;
