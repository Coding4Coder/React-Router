
import { useState } from "react";
import MainHeading from "../../Components/MainHeading";
import FormInput from "./FormInput";
import "./LoginForm.scss";

const LoginForm = () => {
const[values, setValues] = useState({
    username: "",
    email: "",
    birthDay: "",
    password: "",
    confirmPassword: ""
});

//console.log(username);

const handleSubmit = (e) =>{
    e.preventDefault();
    const data = new FormData(e.target)
    // console.log(data);
    //console.log(Object.fromEntries(data.entries()));
}

const inputs = [
    {
        id: 1,
        name: "username",
        type: "text",
        placeholder: "Username"
      
    },
    {
        id: 2,
        name: "email",
        type: "text",
        placeholder: "Email"
      
    },
    {
        id: 3,
        name: "birthDay",
        type: "text",
        placeholder: "Birth Day"
       
    },
    {
        id: 4,
        name: "password",
        type: "password",
        placeholder: "Password"
       
    },
    {
        id: 5,
        name: "confirmPassword",
        type: "password",
        placeholder: "Confirm Password"
       
    }
];

const onChange = (e) =>{
    setValues({...values,[e.target.name]:e.target.value});
}

console.log(values);
    return (
        <div className="main-container">
             <MainHeading pageTitle={"Please Login here"} />
            <div className="loginForm">
             <form onSubmit={handleSubmit} >
               
               {
                   inputs.map((input) => 
                    <FormInput 
                    key={input.id}
                    inputName={input.name}
                    inputType={input.type}
                    inputPlaceHolder={input.placeholder}

                    value={values[input.name]}
                    onChange={onChange}
                    
                     />

                   )
               }
             

            
                <button>Submit</button>
             </form>
            
             </div>
        </div>
    );
}

export default LoginForm;