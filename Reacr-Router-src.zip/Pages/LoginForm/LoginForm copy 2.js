
import React, { useState } from "react";
import MainHeading from "../../Components/MainHeading";

import "./LoginForm.scss";

const LoginForm = () => {
    const[userName, setUserName] = useState("");
    const[userEmail, setUserEmail] = useState("");
    const[userPassword, setUserPassword] = useState("");

   const[newEntry, setNewEntry] = useState([]);
   
   const submitHandler = (e) =>{
       e.preventDefault();
        const newEntry = {loginName: userName, loginEmail: userEmail, loginPassword: userPassword };
        console.log(newEntry);
        setNewEntry([newEntry]);

   }

    return (
        <div className="main-container">
             <MainHeading pageTitle={"Please Login here"} />
            <div className="loginForm">

                
                    {
                       newEntry.map((loginData) => 
                              <div className="login-result">
                                <span>Login : {loginData.loginName}</span>
                                <span>Email : {loginData.loginEmail}</span>
                                <span>Password : {loginData.loginPassword}</span>
                            </div>
                           )
                    }
                

             <form onSubmit={submitHandler}>
             <div className="formInput">
                 <input 
                 type="text" 
                 name="username"
                 id="username"
                 placeholder="User Name"
                 autoComplete="off"
                 value={userName}
                 onChange={(e) => setUserName(e.target.value)}  />

                <input 
                 type="text" 
                 name="email"
                 id="email"
                 placeholder="Email"
                 autoComplete="off"
                 value={userEmail}
                 onChange={(e) => setUserEmail(e.target.value)}  />

                <input 
                 type="password" 
                 name="username"
                 id="username"
                 placeholder="Password"
                 autoComplete="off"
                 value={userPassword}
                 onChange={(e) => setUserPassword(e.target.value)}  />

             </div>
             <button className="btn btn-color">Submit</button>
            </form>
             </div>
        </div>
    );
}

export default LoginForm;