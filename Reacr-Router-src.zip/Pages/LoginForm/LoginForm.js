
import { useState } from "react";
import MainHeading from "../../Components/MainHeading";

import "./LoginForm.scss";

const LoginForm = () => {
    const[username, setUsername] = useState("");
    const[useremail, setUseremail] = useState("");
    const[userpassword, setUserPassword] = useState("");


    const[newEntries, setNewEntries] = useState([]);

    const submitForm = (e) => {
        e.preventDefault();
        const newEntries = {myUsername: username, myUserEmail:useremail, myUserPassword:userpassword}
        setNewEntries([newEntries]);
    }

// counter
const[counter, setCounter] = useState(0);
const changeNumber = () => {
    setCounter(counter+1);
}
// counter ends

// Spread operator
    const car = ["Tata", "Maruti", "Volvo"];
    const allCar = [ "Jeep", ...car, "Safari"];
    console.log(car);
    console.log(allCar);

// Spread operator ends
    const fruits = [
        {
            fname: "Apple",
            rate: 50,
            type: "kashmi"
        },
        {
            fname: "Orange",
            rate: 80,
            type: "Nagpur"
        }
    ];
    const vegis = [
        {
            fname: "Carrot",
            rate: 20,
            type: "Ooty"
        },
        {
            fname: "Layfinger",
            rate: 40,
            type: "Canoor"
        }
    ];
const allItems = [...fruits, ...vegis];
console.log(allItems);



    return (
        <div className="main-container">
             <MainHeading pageTitle={"Please Login here"} />
            <div className="loginForm">
                <div className="txt">
                    <span>{counter}</span> <br />
                    <button className="btn btn-color" onClick={changeNumber}>Count Me</button>
                </div>

                   
                   {
                       newEntries.map(entryData =>
                                <div className="login-result">
                                    <span> User Name : {entryData.myUsername}</span>
                                    <span> Email : {entryData.myUserEmail}</span>
                                    <span> Password : {entryData.myUserPassword}</span>
                            </div>
                        )
                   }
                  

                <form onSubmit={submitForm}>
                    <div className="formInput">

                    <input type="text" name="username" id="username" autoComplete="off" placeholder="User Name" value={username} onChange={(e) => setUsername(e.target.value)} />

                    <input type="text" name="useremail" id="useremail" autoComplete="off" placeholder="Email" value={useremail} onChange={(e) => setUseremail(e.target.value)} />

                    <input type="password" name="userpassword" id="userpassword" autoComplete="off" placeholder="Password" value={userpassword} onChange={(e) => setUserPassword(e.target.value)} />

                    </div>
                    <button className="btn btn-color">Submit</button>
                </form>

             </div>
        </div>
    );
}

export default LoginForm;