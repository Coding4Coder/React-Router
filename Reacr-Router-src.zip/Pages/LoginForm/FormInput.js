


import "./LoginForm.scss";

const FormInput = (props) => {
    return (
 
            <div className="formInput">
                {/* <label>User Name</label> */}
                <input id={props.key}
                name={props.inputName} 
                type={props.inputType}
                placeholder={props.inputPlaceHolder}

                onChange={props.onChange}
                
                />
            </div>
        
    );
}

export default FormInput;