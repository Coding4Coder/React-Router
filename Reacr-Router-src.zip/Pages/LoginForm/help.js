import { useState } from "react";
const SimpleInput = (props) => {
  const [enteredName, setEnteredName] = useState('');
  const [touchedInput, setTouchedInput] = useState(false);
  const [enteredEmail, setEnteredEmail] = useState('');
  const [touchedEmail, setTouchedEmail] = useState(false);
  const isEnteredNameInvalid = enteredName.trim() === '';
  const isInputTextInvalid =  isEnteredNameInvalid && touchedInput;
  const isEmailInvalid = enteredEmail.trim() === '' || !enteredEmail.includes('@');
  const isEmailTextInvalid =  isEmailInvalid && touchedEmail;

  let isValidForm = false;
  if(!isEnteredNameInvalid && !isEmailInvalid) {
    isValidForm = true
  }

  const inputChangeHandler = (event) => {
      setEnteredName(event.target.value);
      setTouchedInput(true);
  }

  const inputBlurHandler = () => {
    setTouchedInput(true);
  }

  const inputEmailChangeHandler = (event) => {
    setEnteredEmail(event.target.value);
    setTouchedEmail(true);
}

const inputEmailBlurHandler = () => {
  setTouchedEmail(true);
}

  const formSubmitHandler = (event) => {
    event.preventDefault();
    setTouchedInput(true);
    setTouchedEmail(true);
    if(isEnteredNameInvalid || isEmailInvalid) {
      return;
    }
    console.log(enteredName + " " + enteredEmail);
  }
  const classes      = isInputTextInvalid ? 'form-control invalid' : 'form-control';
  const emailClasses = isEmailTextInvalid ? 'form-control invalid' : 'form-control'

  return (
    <form onSubmit={formSubmitHandler}>
      <div className={classes}>
        <label htmlFor='name'>Your Name</label>
        <input type='text' id='name' onChange={inputChangeHandler} onBlur={inputBlurHandler} />
        {isInputTextInvalid && <p className="error-tex">Name can not be empty.</p>}
      </div>
      <div className={emailClasses}>
        <label htmlFor='email'>Your Email</label>
        <input type='email' id='email' onChange={inputEmailChangeHandler} onBlur={inputEmailBlurHandler} />
        {isEmailTextInvalid && <p className="error-tex">Email can not be empty.</p>}
      </div>
      <div className="form-actions">
        <button disabled={!isValidForm}>Submit</button>
      </div>
    </form>
  );
};

export default SimpleInput;