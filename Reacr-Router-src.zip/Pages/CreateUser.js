
import "../scss/Dashboard.scss";

const CreateUser = () =>{
    return(
        <div className="card-box">
            <h1 className="heading">Create User</h1>
            <div className="row g-0 bdr-top">
                <div className="col-sm-12">
                    <div className="login-box">
                        <h2 className="title">Please Create User here.. </h2></div>
                </div>
            </div>
            </div>
    );
}
export default CreateUser;
