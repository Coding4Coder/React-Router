

import React from "react";
import "../scss/Main.scss";
import UserTemp from "./UserTemp";

const AboutUser = () =>{

    const newAddedUser = [
        {
            userName : "Roy",
            userAge : 50,
            userIncome : 7000
        },
        {
            userName : "Harry",
            userAge : 60,
            userIncome : 6500
        }
    ];

  const userData = [
        {
            userName : "Rakesh",
            userAge : 30,
            userIncome : 5000
        },
        {
            userName : "Peter",
            userAge : 40,
            userIncome : 2000
        },
        {
            userName : "Micheal",
            userAge : 50,
            userIncome : 1000
        },
        {
            userName: "Max",
            userAge : 30,
            userIncome : 8000,
           

        },
        
            ...newAddedUser  // SPREAD OPERATOR
       
        
  ];
 

    return(
        <React.Fragment>
           
            {
                userData.map( userBinder =>
                            <UserTemp  
                                uName={userBinder.userName} 
                                uAge={userBinder.userAge} 
                                uIncome={userBinder.userIncome}
                            />
                )

            }


        </React.Fragment>
    );
}

export default AboutUser;
