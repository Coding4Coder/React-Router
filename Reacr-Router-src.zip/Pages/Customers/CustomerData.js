

import { useEffect, useState } from "react";
import "../../scss/Main.scss";
import MainHeading from "../../Components/MainHeading";

const CustomerData = () => {
    
    const[users, setUsers] = useState([])

    const  fetchData = () => {
        fetch("https://randomuser.me/api/?results=10")
        .then((response) => {
            console.log(response)
            return response.json();
        })
        .then((data) => {
            console.log(data)  
            let usersList = data.results;
          // console.log(usersList[0].phone) 
           setUsers(usersList);
           
        })
    }

    useEffect(() => {
        fetchData();
    },[])
   
return (
        <div className="main-container">
            <div className="row g-0">

                <div class="card">
                    {users[0].name.first}
                </div>

            </div>
        </div>
);
}

export default CustomerData;