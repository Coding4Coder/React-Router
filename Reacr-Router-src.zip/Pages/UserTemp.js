
import "../scss/Dashboard.scss";

const UserTemp = (props) =>{
    return (
         
            
            <div className="row txt bdr-btm g-0">
                <div className="col-sm-4"> { props.uName }</div>
                <div className="col-sm-4"> { props.uAge }</div>
                <div className="col-sm-4"> { props.uIncome }</div>
            </div>

        

    );
}

export default UserTemp;