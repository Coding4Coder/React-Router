
import { useState } from "react";
import MainHeading from "../../Components/MainHeading";
import "./Registration.scss";

const Registration = () => {

    const[registration, setRegistration] = useState({
        username : "",
        email : "",
        phone : "",
        password : "",
        confirmpassword : ""
    })
    
    const[newrecords, setNewRecord] = useState([]);

    const inputHandler = (e) => {
        const name = e.target.name;
        const value = e.target.value;
       // console.log(name, value);

       setRegistration({...registration, [name] : value});
    }

        const formSubmitHandler = (e) => {
            e.preventDefault();
          const setNewEntries = {...registration};
          setNewRecord([setNewEntries]);
        }

    return (
        <div className="main-container">
            <MainHeading pageTitle="Registration Form" />
            <div className="loginForm">

             <form onSubmit={formSubmitHandler}>
                 {
                     newrecords.map((newData) =>
                     <div className="login-result">
                        <span>User Name:{newData.username}</span>,
                        <span>Email: {newData.email}</span>,
                        <span>Phone: {newData.phone}</span>,
                        <span>Password: {newData.password}</span>,
                        <span>Confirm Password: {newData.confirmpassword}</span>
                    </div>
                     )
                 }

             <div className="formInput">
                <input type="text" name="username" id="username" value={registration.username} autoComplete="off" placeholder="User Name" 
                onChange={inputHandler} />

                <input type="text" name="email" id="email" value={registration.email} autoComplete="off" placeholder="email"
                onChange={inputHandler} />

                <input type="number" name="phone" id="phone" value={registration.phone} autoComplete="off" placeholder="Phone Number"
                onChange={inputHandler} />

                <input type="password" name="password" id="password" value={registration.password} autoComplete="off" placeholder="Password"
                onChange={inputHandler} />

                <input type="password" name="confirmpassword" id="confirmpassword" value={registration.confirmpassword} autoComplete="off" placeholder="Confirm Password"
                onChange={inputHandler} />
                </div>  
                <button className="btn btn-color">Submit</button> 
             </form>
             </div>   
        </div>
    );
}

export default Registration;