
import { Link, NavLink } from "react-router-dom";
import "../scss/Main.scss";
import logo from "../img/logo.png";

const TopNavBar = () => {
    return (
        <header className="nav-bar">  
            <div className="row g-0">
                <div className="col-sm-2">
                    <div className="logo"><img src={ logo } alt="Sky logo" /></div>
                </div>
                <div className="col-sm-10">
                    <nav className="nav-links">
                        <ul>
                            <li><NavLink to="/home">Home</NavLink></li>
                            <li><NavLink to="/about" >About</NavLink></li>
                            <li><NavLink to="/dashboard" >Dashboard</NavLink></li>
                            <li><NavLink to="/login" >Login</NavLink></li>
                            <li><NavLink to="/register">Register</NavLink></li>
                            <li><NavLink to="/signup">Signup</NavLink></li>
                            <li><NavLink to="/calculator">Calculator</NavLink></li>
                            <li><NavLink to="/customer">Customers</NavLink></li>

                        </ul>
                    </nav>
                </div>
            </div>
        </header> 
    );
}

export default TopNavBar;
