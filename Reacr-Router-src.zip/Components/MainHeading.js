import classes from "../scss/Home.module.scss";

const MainHeading = (props) => {
    return (
        <h1 className={classes.heading}>
            {props.pageTitle}
        </h1>
    );
}

export default MainHeading;